
**This folder is used to place your Mx-PWA App Icons, please DO NOT change the name of this folder**

**App Icons:**
* should be of `.png` format.
* you should add 3 icons with the following dimensions `[128x128, 192x192, 512x512]`